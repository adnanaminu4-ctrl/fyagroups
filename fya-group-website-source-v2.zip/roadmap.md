# Roadmap

- [x] Install FYA GROUPS logo (monogram concept) in header, footer, favicon
- [x] Recolor logo to navy blue (user request)
