import { createFileRoute } from "@tanstack/react-router";
import { PageHero } from "@/components/SiteChrome";
import { company } from "@/lib/divisions";
import estate from "@/assets/estate.jpg";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About FYA Groups — Nigerian Diversified Group" },
      { name: "description", content: "FYA Engineering Services Ltd (RC 1811637) is a Kano-born group delivering construction, real estate, water, poultry, energy and travel." },
      { property: "og:title", content: "About FYA Groups" },
      { property: "og:description", content: "Our story, values and leadership." },
    ],
  }),
  component: About,
});

const values = [
  ["Integrity", "Transparent pricing, honest timelines and certified work."],
  ["Quality", "Engineers' specifications followed to the millimetre."],
  ["Safety", "Safe sites, safe water, safe food and safe travel."],
  ["Community", "Local jobs and lasting infrastructure for Nigeria."],
];

function About() {
  return (
    <>
      <PageHero eyebrow="About us" title="Rooted in Kano. Building for Nigeria." image={estate} />
      <section className="mx-auto grid max-w-[1400px] gap-12 px-6 lg:px-10 py-24 md:grid-cols-2">
        <div>
          <p className="eyebrow">Our story</p>
          <h2 className="mt-3 text-3xl font-extrabold sm:text-4xl">From engineering firm to diversified group.</h2>
        </div>
        <div className="space-y-4 text-muted-foreground">
          <p>Incorporated on 28 June 2021 under the Companies and Allied Matters Act 2020, {company.legal} began as a civil and structural engineering firm — building designs, construction supervision, geotechnical investigation and road construction.</p>
          <p>Today FYA Groups has grown into six divisions spanning real estate, table water production, poultry farming, oil & gas supply and a full travel agency, all driven by the same engineering discipline.</p>
          <p className="font-semibold text-foreground">Led by Managing Director Abba Farouq Yusufa.</p>
        </div>
      </section>
      <section className="bg-ink text-ink-foreground">
        <div className="mx-auto grid max-w-[1400px] gap-px px-6 lg:px-10 py-24 md:grid-cols-2">
          <div className="p-8"><p className="eyebrow">Vision</p><p className="mt-4 font-display text-2xl font-bold">To be Nigeria's most trusted diversified group, building infrastructure and essentials that improve everyday life.</p></div>
          <div className="p-8"><p className="eyebrow">Mission</p><p className="mt-4 font-display text-2xl font-bold">Deliver quality projects and products on time, safely and at fair value — every division, every client.</p></div>
        </div>
      </section>
      <section className="mx-auto max-w-[1400px] px-6 lg:px-10 py-24">
        <p className="eyebrow">Our values</p>
        <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {values.map(([t, d]) => (
            <div key={t} className="rounded-md border bg-card p-6"><h3 className="text-xl font-extrabold">{t}</h3><p className="mt-2 text-sm text-muted-foreground">{d}</p></div>
          ))}
        </div>
      </section>
    </>
  );
}
