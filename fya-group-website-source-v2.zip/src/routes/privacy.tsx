import { createFileRoute } from "@tanstack/react-router";
import { PageHero } from "@/components/SiteChrome";
import { company } from "@/lib/divisions";
import img from "@/assets/estate.jpg";

export const Route = createFileRoute("/privacy")({
  head: () => ({
    meta: [
      { title: "Privacy Policy — FYA Groups" },
      { name: "description", content: "How FYA Groups collects and uses information you share with us." },
      { property: "og:title", content: "Privacy Policy — FYA Groups" },
      { property: "og:description", content: "How FYA Groups collects and uses information you share with us." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Privacy,
});

const items: [string, string][] = [["Information we collect", "Only what you choose to send us \u2014 such as your name, phone number, email and project details \u2014 through our contact form, Project Advisor, email or WhatsApp."], ["How we use it", "To reply to your enquiry, prepare quotes and deliver our services. We do not sell your information."], ["Project Advisor", "Text you type into the Project Advisor is processed by an AI service to generate a recommendation. It is not stored on our website."], ["Your rights", "You can ask us to see, correct or delete your information at any time by emailing us."], ["Updates", "We may update this policy. The latest version will always be on this page."]];

function Privacy() {
  return (
    <>
      <PageHero eyebrow="Legal" title="Privacy Policy" image={img} />
      <section className="mx-auto max-w-4xl px-6 py-20 lg:px-10">
        <div className="divide-y divide-border">
          {items.map(([q, a]) => (
            <div key={q} className="py-6">
              <h2 className="text-xl font-bold">{q}</h2>
              <p className="mt-2 leading-relaxed text-muted-foreground">{a}</p>
            </div>
          ))}
        </div>
        <p className="mt-10 text-sm text-muted-foreground">Questions? Email {company.email} or call {company.phones[0]}.</p>
      </section>
    </>
  );
}
