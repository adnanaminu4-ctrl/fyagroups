import { createFileRoute, Link } from "@tanstack/react-router";
import hero from "@/assets/hero.jpg";
import estate from "@/assets/estate.jpg";
import { divisions, company } from "@/lib/divisions";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "FYA Groups — Roads, Real Estate, Water, Poultry, Oil & Gas, Travel" },
      { name: "description", content: "FYA Groups is a Nigerian conglomerate in road construction, building, table water, poultry, oil & gas and travel services." },
      { property: "og:title", content: "FYA Groups — Building Nigeria, Every Day" },
      { property: "og:description", content: "Six divisions. One standard of excellence. Roads, homes, water, poultry, energy and travel." },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <>
      <section className="relative flex min-h-screen items-end overflow-hidden bg-ink text-ink-foreground">
        <img src={hero} alt="FYA road construction at sunset" width={1920} height={1088} className="absolute inset-0 h-full w-full object-cover" />
        <div className="absolute inset-0 bg-fade" />
        <div className="relative mx-auto w-full max-w-[1400px] px-6 lg:px-10 pb-20 pt-32">
          <p className="eyebrow animate-in fade-in slide-in-from-bottom-4 duration-700">Est. {company.founded} · Kano & Abuja</p>
          <h1 className="mt-4 max-w-5xl text-4xl font-extrabold leading-[0.95] sm:text-6xl md:text-8xl animate-in fade-in slide-in-from-bottom-6 duration-1000">
            We build the roads.<br />And everything <span className="text-primary">along them.</span>
          </h1>
          <p className="mt-6 max-w-xl text-lg opacity-80">Six divisions — construction, real estate, table water, poultry, oil & gas and travel — under one trusted Nigerian group.</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link to="/divisions" className="rounded-sm bg-primary px-6 lg:px-10 py-3 font-bold text-primary-foreground">Explore divisions</Link>
            <Link to="/contact" className="rounded-sm border border-ink-foreground/30 px-6 lg:px-10 py-3 font-bold">Request a quote</Link>
          </div>
          <div className="mt-16 grid max-w-3xl grid-cols-2 gap-6 border-t border-ink-foreground/15 pt-8 md:grid-cols-4">
            {[["6", "Business divisions"], ["2", "State offices"], ["RC", "1811637 CAC"], ["24/7", "Client support"]].map(([a, b]) => (
              <div key={b}><p className="font-display text-3xl font-extrabold text-primary">{a}</p><p className="text-sm opacity-70">{b}</p></div>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-[1400px] px-6 lg:px-10 py-24">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div><p className="eyebrow">What we do</p><h2 className="mt-3 text-3xl font-extrabold sm:text-4xl md:text-6xl">One group. Six engines.</h2></div>
          <Link to="/divisions" className="font-bold underline underline-offset-4">All divisions →</Link>
        </div>
        <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {divisions.map((d) => (
            <Link key={d.slug} to="/divisions" hash={d.slug} className="group relative block aspect-[4/5] overflow-hidden rounded-md bg-ink text-ink-foreground shadow-lift">
              <img src={d.image} alt={d.title} loading="lazy" className="absolute inset-0 h-full w-full object-cover transition duration-700 group-hover:scale-105" />
              <div className="absolute inset-0 bg-fade" />
              <div className="absolute inset-x-0 bottom-0 p-6">
                <p className="font-display text-sm text-primary">{d.no}</p>
                <h3 className="mt-1 text-2xl font-extrabold">{d.title}</h3>
                <p className="mt-2 text-sm opacity-80">{d.short}</p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      <section className="bg-secondary">
        <div className="mx-auto grid max-w-[1400px] items-center gap-12 px-6 lg:px-10 py-24 md:grid-cols-2">
          <img src={estate} alt="FYA estate development" loading="lazy" className="aspect-[4/3] w-full rounded-md object-cover shadow-lift" />
          <div>
            <p className="eyebrow">Featured project</p>
            <h2 className="mt-3 text-3xl font-extrabold sm:text-4xl md:text-5xl">Proposed Estate Development</h2>
            <p className="mt-5 text-muted-foreground">Our 2026 estate brings family duplexes with spacious living rooms, family lounges, private lifts, boys' quarters and modern kitchens — designed in-house and built by our own engineers.</p>
            <ul className="mt-6 grid grid-cols-2 gap-3 text-sm font-semibold">
              {["36 m² living rooms", "Private lift access", "Family lounge & foyer", "Boys' quarters (BQ)"].map((x) => <li key={x} className="border-l-2 border-primary pl-3">{x}</li>)}
            </ul>
            <Link to="/contact" className="mt-8 inline-block rounded-sm bg-ink px-6 lg:px-10 py-3 font-bold text-ink-foreground">Reserve a unit</Link>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-[1400px] px-6 lg:px-10 py-24 text-center">
        <h2 className="mx-auto max-w-3xl text-3xl font-extrabold sm:text-4xl md:text-6xl">Have a project in mind? <span className="text-primary">Let's build it.</span></h2>
        <Link to="/contact" className="mt-10 inline-block rounded-sm bg-primary px-8 py-4 font-bold text-primary-foreground">Contact FYA Groups</Link>
      </section>
    </>
  );
}
