import { createFileRoute } from "@tanstack/react-router";
import { PageHero } from "@/components/SiteChrome";
import { company } from "@/lib/divisions";
import img from "@/assets/estate.jpg";

export const Route = createFileRoute("/terms")({
  head: () => ({
    meta: [
      { title: "Terms of Use — FYA Groups" },
      { name: "description", content: "Terms for using the FYA Groups website." },
      { property: "og:title", content: "Terms of Use — FYA Groups" },
      { property: "og:description", content: "Terms for using the FYA Groups website." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Terms,
});

const items: [string, string][] = [["Use of this website", "This website provides information about FYA Groups and its services. Content may change without notice."], ["Quotes and estimates", "Prices or recommendations shown online, including AI suggestions, are indicative only. A binding quote is issued in writing after assessment."], ["Images", "Some images on this site are illustrations and may not show actual completed projects."], ["Intellectual property", "The FYA Groups name, logo and content belong to FYA Engineering Services Ltd and may not be reused without permission."], ["Governing law", "These terms are governed by the laws of the Federal Republic of Nigeria."]];

function Terms() {
  return (
    <>
      <PageHero eyebrow="Legal" title="Terms of Use" image={img} />
      <section className="mx-auto max-w-4xl px-6 py-20 lg:px-10">
        <div className="divide-y divide-border">
          {items.map(([q, a]) => (
            <div key={q} className="py-6">
              <h2 className="text-xl font-bold">{q}</h2>
              <p className="mt-2 leading-relaxed text-muted-foreground">{a}</p>
            </div>
          ))}
        </div>
        <p className="mt-10 text-sm text-muted-foreground">Questions? Email {company.email} or call {company.phones[0]}.</p>
      </section>
    </>
  );
}
