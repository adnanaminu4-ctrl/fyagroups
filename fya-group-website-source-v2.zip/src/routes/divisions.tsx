import { createFileRoute, Link } from "@tanstack/react-router";
import { divisions } from "@/lib/divisions";
import { PageHero } from "@/components/SiteChrome";
import oil from "@/assets/oil.jpg";

export const Route = createFileRoute("/divisions")({
  head: () => ({
    meta: [
      { title: "Our Divisions — FYA Groups" },
      { name: "description", content: "Road construction, building & real estate, table water, poultry, oil & gas and travel agency services by FYA Groups." },
      { property: "og:title", content: "Our Divisions — FYA Groups" },
      { property: "og:description", content: "Explore the six businesses that power FYA Groups." },
    ],
  }),
  component: Divisions,
});

function Divisions() {
  return (
    <>
      <PageHero eyebrow="Our divisions" title="Diversified by design." image={oil} />
      <div className="mx-auto max-w-[1400px] px-6 lg:px-10 py-20">
        {divisions.map((d, i) => (
          <section key={d.slug} id={d.slug} className="grid scroll-mt-24 items-center gap-10 border-b py-16 last:border-0 md:grid-cols-2">
            <img src={d.image} alt={d.title} loading="lazy" className={`aspect-[4/3] w-full rounded-md object-cover shadow-lift ${i % 2 ? "md:order-2" : ""}`} />
            <div>
              <p className="font-display text-5xl font-extrabold text-primary/30 md:text-6xl">{d.no}</p>
              <h2 className="text-3xl font-extrabold sm:text-4xl">{d.title}</h2>
              <p className="mt-4 text-muted-foreground">{d.body}</p>
              <ul className="mt-6 grid grid-cols-2 gap-3 text-sm font-semibold">
                {d.points.map((p) => <li key={p} className="border-l-2 border-primary pl-3">{p}</li>)}
              </ul>
              <Link to="/contact" className="mt-8 inline-block rounded-sm bg-ink px-5 py-3 text-sm font-bold text-ink-foreground">Enquire about {d.title}</Link>
            </div>
          </section>
        ))}
      </div>
    </>
  );
}
