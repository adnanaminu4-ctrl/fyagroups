import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { PageHero } from "@/components/SiteChrome";
import { company } from "@/lib/divisions";
import { recommendService, type AdvisorResult } from "@/lib/advisor.functions";
import hero from "@/assets/hero.jpg";

export const Route = createFileRoute("/advisor")({
  head: () => ({
    meta: [
      { title: "Project Advisor — FYA Groups" },
      { name: "description", content: "Describe your project and get an instant recommendation of the right FYA Groups service plus a ready-to-send inquiry." },
      { property: "og:title", content: "FYA Groups Project Advisor" },
      { property: "og:description", content: "Tell us what you need — we'll match you to the right division and draft your inquiry." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Advisor,
});

function Advisor() {
  const run = useServerFn(recommendService);
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [res, setRes] = useState<AdvisorResult | null>(null);
  const [summary, setSummary] = useState("");

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true); setError(""); setRes(null);
    try {
      const out = await run({ data: { description: text } });
      if (out.error || !out.result) setError(out.error ?? "No answer.");
      else { setRes(out.result); setSummary(out.result.summary); }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong.");
    } finally { setLoading(false); }
  };

  const mail = res
    ? `mailto:${company.email}?subject=${encodeURIComponent("Enquiry: " + res.division)}&body=${encodeURIComponent(summary)}`
    : "#";

  return (
    <>
      <PageHero eyebrow="Project Advisor" title="Tell us what you need." image={hero} />
      <section className="mx-auto grid max-w-[1400px] gap-10 px-6 lg:px-10 py-20 lg:grid-cols-2">
        <form onSubmit={submit} className="space-y-4 rounded-md border bg-card p-5 shadow-lift sm:p-8">
          <p className="eyebrow">Describe your project</p>
          <textarea
            required rows={8} value={text} onChange={(e) => setText(e.target.value)}
            placeholder="e.g. I want to build a 4-bedroom duplex in Kano and need a borehole and table water supply for the estate…"
            className="w-full rounded-sm border bg-background px-4 py-3 outline-none focus:ring-2 focus:ring-ring"
          />
          <button disabled={loading} className="w-full rounded-sm bg-primary px-6 lg:px-10 py-4 font-bold text-primary-foreground disabled:opacity-60">
            {loading ? "Analysing your project…" : "Get my recommendation"}
          </button>
          {error && <p className="text-sm text-destructive">{error}</p>}
        </form>

        <div className="rounded-md border bg-card p-5 sm:p-8">
          {!res && !loading && <p className="text-muted-foreground">Your recommended service and a ready-to-send inquiry will appear here.</p>}
          {loading && <p className="animate-pulse text-muted-foreground">Matching you with the right FYA Groups division…</p>}
          {res && (
            <div className="space-y-6">
              <div>
                <p className="eyebrow">Recommended service</p>
                <h2 className="mt-2 font-display text-3xl font-bold text-primary">{res.division}</h2>
                <p className="mt-2 text-muted-foreground">{res.reason}</p>
                {res.related.filter((r) => r !== res.division).length > 0 && (
                  <p className="mt-2 text-sm">Also relevant: {res.related.filter((r) => r !== res.division).join(", ")}</p>
                )}
              </div>
              <div>
                <p className="eyebrow">Your inquiry (edit if needed)</p>
                <textarea rows={8} value={summary} onChange={(e) => setSummary(e.target.value)}
                  className="mt-2 w-full rounded-sm border bg-background px-4 py-3 outline-none focus:ring-2 focus:ring-ring" />
              </div>
              {res.questions.length > 0 && (
                <div>
                  <p className="eyebrow">Be ready to answer</p>
                  <ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-muted-foreground">
                    {res.questions.map((q) => <li key={q}>{q}</li>)}
                  </ul>
                </div>
              )}
              <div className="flex flex-col gap-3 sm:flex-row">
                <a href={mail} className="rounded-sm bg-primary px-6 lg:px-10 py-3 text-center font-bold text-primary-foreground">Send inquiry by email</a>
                <button type="button" onClick={() => navigator.clipboard.writeText(summary)} className="rounded-sm border px-6 lg:px-10 py-3 font-bold">Copy text</button>
                <Link to="/contact" className="rounded-sm border px-6 lg:px-10 py-3 text-center font-bold">Contact page</Link>
              </div>
            </div>
          )}
        </div>
      </section>
    </>
  );
}
