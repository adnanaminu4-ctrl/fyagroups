import { createFileRoute } from "@tanstack/react-router";
import { PageHero } from "@/components/SiteChrome";
import { company } from "@/lib/divisions";
import img from "@/assets/hero.jpg";

export const Route = createFileRoute("/faq")({
  head: () => ({
    meta: [
      { title: "Frequently asked questions — FYA Groups" },
      { name: "description", content: "Answers to common questions about FYA Groups services, quotes and locations." },
      { property: "og:title", content: "Frequently asked questions — FYA Groups" },
      { property: "og:description", content: "Answers to common questions about FYA Groups services, quotes and locations." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Faq,
});

const items: [string, string][] = [["What services does FYA Groups offer?", "Road construction, building & real estate, table water, poultry farming, oil & gas, and a travel agency."], ["Where do you operate?", "Our head office is in Kano and we have an office in Abuja. We take on projects across Nigeria."], ["How do I request a quote?", "Use the Contact page, the Project Advisor, or call/WhatsApp us. We usually reply within one working day."], ["Is FYA Groups a registered company?", "Yes. FYA Engineering Services Ltd is registered with the CAC (RC 1811637) under CAMA 2020."], ["Can I combine several services in one project?", "Yes \u2014 for example a road, housing and water supply for one estate. One team coordinates it all."], ["Do you supply table water in bulk?", "Yes, we supply homes, offices, shops and events. Contact us for bulk pricing."]];

function Faq() {
  return (
    <>
      <PageHero eyebrow="Help" title="Frequently asked questions" image={img} />
      <section className="mx-auto max-w-4xl px-6 py-20 lg:px-10">
        <div className="divide-y divide-border">
          {items.map(([q, a]) => (
            <div key={q} className="py-6">
              <h2 className="text-xl font-bold">{q}</h2>
              <p className="mt-2 leading-relaxed text-muted-foreground">{a}</p>
            </div>
          ))}
        </div>
        <p className="mt-10 text-sm text-muted-foreground">Questions? Email {company.email} or call {company.phones[0]}.</p>
      </section>
    </>
  );
}
