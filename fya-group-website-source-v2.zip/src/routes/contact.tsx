import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHero } from "@/components/SiteChrome";
import { company, divisions } from "@/lib/divisions";
import travel from "@/assets/travel.jpg";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact FYA Groups — Get a Quote" },
      { name: "description", content: "Reach FYA Groups in Kano or Abuja for construction, real estate, table water, poultry, oil & gas or travel enquiries." },
      { property: "og:title", content: "Contact FYA Groups" },
      { property: "og:description", content: "Request a quote from any FYA Groups division." },
    ],
  }),
  component: Contact,
});

function Contact() {
  const [form, setForm] = useState({ name: "", phone: "", division: divisions[0]?.title ?? "", message: "" });
  const field = "w-full rounded-sm border bg-card px-4 py-3 outline-none focus:ring-2 focus:ring-ring";
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const body = encodeURIComponent(`Name: ${form.name}\nPhone: ${form.phone}\nDivision: ${form.division}\n\n${form.message}`);
    window.location.href = `mailto:${company.email}?subject=${encodeURIComponent("Enquiry: " + form.division)}&body=${body}`;
  };
  return (
    <>
      <PageHero eyebrow="Contact" title="Let's start your project." image={travel} />
      <section className="mx-auto grid max-w-[1400px] gap-12 px-6 lg:px-10 py-24 md:grid-cols-5">
        <div className="space-y-8 md:col-span-2">
          <div><p className="eyebrow">Head office</p><p className="mt-2">{company.address}</p></div>
          <div><p className="eyebrow">Abuja office</p><p className="mt-2">{company.office2}</p></div>
          <div><p className="eyebrow">Phone</p>{company.phones.map((p) => <a key={p} href={`tel:${p.replace(/\s/g, "")}`} className="mt-2 block font-semibold">{p}</a>)}</div>
          <div><p className="eyebrow">Email</p><a href={`mailto:${company.email}`} className="mt-2 block font-semibold">{company.email}</a></div>
        </div>
        <form onSubmit={submit} className="space-y-4 rounded-md border bg-card p-5 shadow-lift sm:p-8 md:col-span-3">
          <input required placeholder="Full name" className={field} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          <input required placeholder="Phone number" className={field} value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
          <select className={field} value={form.division} onChange={(e) => setForm({ ...form, division: e.target.value })}>
            {divisions.map((d) => <option key={d.slug}>{d.title}</option>)}
          </select>
          <textarea required rows={5} placeholder="Tell us about your needs" className={field} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} />
          <button className="w-full rounded-sm bg-primary px-6 lg:px-10 py-4 font-bold text-primary-foreground">Send enquiry</button>
        </form>
      </section>
    </>
  );
}
