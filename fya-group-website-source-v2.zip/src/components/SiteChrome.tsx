import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { company } from "@/lib/divisions";
import logo from "@/assets/logo.png";

const nav = [
  { to: "/", label: "Home" },
  { to: "/divisions", label: "Divisions" },
  { to: "/about", label: "About" },
  { to: "/advisor", label: "Project Advisor" },
  { to: "/faq", label: "FAQ" },
  { to: "/contact", label: "Contact" },
] as const;

export function Header() {
  const [open, setOpen] = useState(false);
  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b border-ink-foreground/10 bg-ink/85 text-ink-foreground backdrop-blur">
      <div className="mx-auto flex h-16 max-w-[1400px] items-center justify-between px-6 lg:px-10">
        <Link to="/" className="flex items-center gap-3">
          <img src={logo} alt="FYA Groups logo" width={1024} height={1024} className="h-10 w-auto" />
          <span className="font-display text-xl font-extrabold">FYA<span className="text-primary">GROUPS</span></span>
        </Link>
        <nav className="hidden gap-6 lg:gap-8 md:flex">
          {nav.map((n) => (
            <Link key={n.to} to={n.to} className="text-sm font-semibold opacity-80 transition hover:opacity-100" activeProps={{ className: "text-primary opacity-100" }} activeOptions={{ exact: true }}>
              {n.label}
            </Link>
          ))}
        </nav>
        <Link to="/contact" className="hidden rounded-sm bg-primary px-4 py-2 text-sm font-bold text-primary-foreground md:inline-block">
          Get a quote
        </Link>
        <button className="shrink-0 p-2 text-2xl leading-none md:hidden" onClick={() => setOpen(!open)} aria-label="Menu" aria-expanded={open}>{open ? "✕" : "☰"}</button>
      </div>
      {open && (
        <div className="flex flex-col gap-4 border-t border-ink-foreground/10 px-6 lg:px-10 pb-6 pt-4 md:hidden">
          {nav.map((n) => (
            <Link key={n.to} to={n.to} onClick={() => setOpen(false)} className="font-semibold" activeProps={{ className: "text-primary" }} activeOptions={{ exact: true }}>{n.label}</Link>
          ))}
          <Link to="/contact" onClick={() => setOpen(false)} className="mt-2 rounded-sm bg-primary px-4 py-3 text-center text-sm font-bold text-primary-foreground">Get a quote</Link>
        </div>
      )}
    </header>
  );
}

export function Footer() {
  return (
    <footer className="bg-ink text-ink-foreground">
      <div className="mx-auto grid max-w-[1400px] gap-10 px-6 lg:px-10 py-16 md:grid-cols-4">
        <div className="md:col-span-2">
          <img src={logo} alt="FYA Groups logo" width={1024} height={1024} className="h-16 w-auto" loading="lazy" />
          <p className="mt-4 max-w-sm text-sm opacity-70">Building Nigeria's roads, homes and everyday essentials — from Kano to Abuja and beyond.</p>
          <p className="mt-4 text-xs opacity-50">{company.legal} · {company.rc}</p>
        </div>
        <div className="text-sm">
          <p className="eyebrow mb-3">Visit</p>
          <p className="opacity-70">{company.address}</p>
          <p className="mt-2 opacity-70">{company.office2}</p>
        </div>
        <div className="text-sm">
          <p className="eyebrow mb-3">Talk to us</p>
          {company.phones.map((p) => <p key={p} className="opacity-70">{p}</p>)}
          <p className="mt-2 opacity-70">{company.email}</p>
        </div>
      </div>
      <div className="mx-auto flex max-w-[1400px] flex-col items-center justify-between gap-3 border-t border-ink-foreground/10 px-6 py-6 text-xs opacity-70 sm:flex-row lg:px-10">
        <span>© {new Date().getFullYear()} FYA Groups. All rights reserved.</span>
        <span className="flex gap-5"><Link to="/faq">FAQ</Link><Link to="/privacy">Privacy Policy</Link><Link to="/terms">Terms of Use</Link></span>
      </div>
      <a href="https://wa.me/2349091707000" target="_blank" rel="noopener noreferrer" aria-label="Chat with us on WhatsApp" className="fixed bottom-5 right-5 z-50 rounded-full bg-primary px-5 py-3 text-sm font-bold text-primary-foreground shadow-lift transition hover:scale-105">WhatsApp us</a>
    </footer>
  );
}

export function PageHero({ eyebrow, title, image }: { eyebrow: string; title: string; image: string }) {
  return (
    <section className="relative flex h-[55vh] min-h-[380px] items-end overflow-hidden bg-ink text-ink-foreground">
      <img src={image} alt="" className="absolute inset-0 h-full w-full object-cover opacity-60" />
      <div className="absolute inset-0 bg-fade" />
      <div className="relative mx-auto w-full max-w-[1400px] px-6 lg:px-10 pb-14">
        <p className="eyebrow">{eyebrow}</p>
        <h1 className="mt-3 max-w-3xl text-4xl font-extrabold sm:text-5xl md:text-7xl">{title}</h1>
      </div>
    </section>
  );
}
