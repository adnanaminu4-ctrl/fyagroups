import { createServerFn } from "@tanstack/react-start";

export type AdvisorResult = {
  division: string;
  reason: string;
  related: string[];
  summary: string;
  questions: string[];
};

const SERVICES = [
  "Road Construction",
  "Building & Real Estate",
  "Table Water",
  "Poultry Farming",
  "Oil & Gas",
  "Travel Agency",
];

const schema = {
  type: "object",
  additionalProperties: false,
  required: ["division", "reason", "related", "summary", "questions"],
  properties: {
    division: { type: "string", enum: SERVICES },
    reason: { type: "string" },
    related: { type: "array", items: { type: "string", enum: SERVICES } },
    summary: { type: "string" },
    questions: { type: "array", items: { type: "string" } },
  },
};

const instructions = `You are the project advisor for FYA GROUPS, a diversified Nigerian company (Kano head office, Abuja office) with six divisions: ${SERVICES.join(", ")}.
Read the customer's description, pick the single most relevant division, list any other relevant divisions (may be empty), and explain why in 1-2 sentences.
Write "summary" as a clear, professional inquiry message (80-150 words) the customer can send to FYA GROUPS, written in first person from the customer, including the key details they gave (location, scale, timeline, budget if mentioned).
List 2-4 short follow-up questions FYA GROUPS will likely ask. Never invent prices or promises.`;

export const recommendService = createServerFn({ method: "POST" })
  .inputValidator((d: { description: string }) => {
    const description = String(d?.description ?? "").trim();
    if (description.length < 10) throw new Error("Please describe your project in a bit more detail.");
    return { description: description.slice(0, 3000) };
  })
  .handler(async ({ data }): Promise<{ result?: AdvisorResult; error?: string }> => {
    const key = process.env["LOVABLE_API_KEY"];
    if (!key) return { error: "The advisor is not configured yet." };
    const res = await fetch("https://ai.gateway.lovable.dev/v1/responses", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${key}`,
        "Content-Type": "application/json",
        "X-Lovable-AIG-SDK": "fetch",
      },
      body: JSON.stringify({
        model: "openai/gpt-6-astra",
        instructions,
        input: [{ role: "user", content: data.description }],
        reasoning: { effort: "low" },
        store: false,
        stream: true,
        text: { format: { type: "json_schema", name: "advice", strict: true, schema } },
      }),
    });
    if (!res.ok || !res.body) {
      const body = await res.text().catch(() => "");
      console.error("advisor gateway error", res.status, body);
      if (res.status === 429) return { error: "The advisor is busy right now. Please try again in a minute." };
      if (res.status === 402 || res.status === 403) return { error: "The advisor is temporarily unavailable. Please contact us directly." };
      return { error: "Something went wrong. Please try again later." };
    }
    const reader = res.body.getReader();
    const dec = new TextDecoder();
    let buf = "";
    let text = "";
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      let i;
      while ((i = buf.indexOf("\n")) >= 0) {
        const line = buf.slice(0, i).trim();
        buf = buf.slice(i + 1);
        if (!line.startsWith("data:")) continue;
        const payload = line.slice(5).trim();
        if (!payload || payload === "[DONE]") continue;
        try {
          const ev = JSON.parse(payload);
          if (ev.type === "response.output_text.delta") text += ev.delta ?? "";
          if (ev.type === "response.refusal.delta" || ev.type === "response.failed")
            return { error: "The advisor couldn't help with this request. Please contact us directly." };
        } catch {
          /* partial */
        }
      }
    }
    try {
      return { result: JSON.parse(text) as AdvisorResult };
    } catch {
      return { error: "The advisor gave an unclear answer. Please try again." };
    }
  });
