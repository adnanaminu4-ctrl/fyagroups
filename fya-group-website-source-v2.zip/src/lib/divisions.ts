import hero from "@/assets/hero.jpg";
import estate from "@/assets/estate.jpg";
import water from "@/assets/water.jpg";
import poultry from "@/assets/poultry.jpg";
import oil from "@/assets/oil.jpg";
import travel from "@/assets/travel.jpg";

export const company = {
  name: "FYA Groups",
  legal: "FYA Engineering Services Ltd",
  rc: "RC 1811637",
  founded: "2021",
  address: "No. 208, Zoo Road Housing Estate, Kano, Kano State, Nigeria",
  office2: "Plot 1250, Garba Ali Close, Guzape, Abuja, FCT",
  email: "farouqyusufa@gmail.com",
  phones: ["0909 170 7000", "0703 040 3538"],
};

export const divisions = [
  {
    slug: "roads",
    no: "01",
    title: "Road Construction",
    short: "Highways, drainage, culverts and urban roads built to last.",
    body: "Civil and structural engineering covering road construction, geotechnical investigation, drainage, culverts and dams — delivered with our own fleet and site supervision teams.",
    points: ["Highways & estate roads", "Drainage & culverts", "Geotechnical investigation", "Dams & reservoirs"],
    image: hero,
  },
  {
    slug: "real-estate",
    no: "02",
    title: "Building & Real Estate",
    short: "Design-build estates, duplexes and commercial structures.",
    body: "From architectural design to handover: building designs, construction supervision, interior & exterior finishing, and full estate developments across Kano and Abuja.",
    points: ["Estate development", "Building design & supervision", "Interior & exterior finishing", "Renovation & maintenance"],
    image: estate,
  },
  {
    slug: "table-water",
    no: "03",
    title: "Table Water",
    short: "Purified bottled and sachet water, NAFDAC-grade hygiene.",
    body: "Borehole drilling, water treatment and modern bottling lines produce clean, safe drinking water for homes, offices and events.",
    points: ["Bottled & sachet water", "Borehole drilling", "Water treatment", "Bulk distribution"],
    image: water,
  },
  {
    slug: "poultry",
    no: "04",
    title: "Poultry Farming",
    short: "Broilers, layers and fresh eggs from climate-controlled farms.",
    body: "Modern poultry houses raising healthy broilers and layers, supplying fresh eggs and birds to markets, hotels and households.",
    points: ["Broilers & layers", "Fresh table eggs", "Day-old chicks", "Wholesale supply"],
    image: poultry,
  },
  {
    slug: "oil-gas",
    no: "05",
    title: "Oil & Gas",
    short: "LPG, petroleum products supply and haulage logistics.",
    body: "Supply and distribution of LPG and petroleum products, backed by our road transportation, logistics and haulage capability.",
    points: ["LPG retail & bulk", "Petroleum products supply", "Haulage & logistics", "Station services"],
    image: oil,
  },
  {
    slug: "travel",
    no: "06",
    title: "Travel Agency",
    short: "Flights, Hajj & Umrah, visas and corporate travel.",
    body: "Local and international flight bookings, Hajj & Umrah packages, visa processing, hotel reservations and corporate travel management.",
    points: ["Flight tickets", "Hajj & Umrah", "Visa assistance", "Hotels & tours"],
    image: travel,
  },
];
